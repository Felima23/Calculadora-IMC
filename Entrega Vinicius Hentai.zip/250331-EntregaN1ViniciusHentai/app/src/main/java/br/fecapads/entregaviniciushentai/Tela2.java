package br.fecapads.entregaviniciushentai;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.DecimalFormat;

public class Tela2 extends AppCompatActivity {

    private Button btnSet;
    private Button btnReset;
    private EditText campoAltura;
    private EditText campoPeso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }


    public void calcularIMC(View view) {

        btnSet = findViewById(R.id.btnSet);
        btnReset = findViewById(R.id.btnReset);
        campoAltura = findViewById(R.id.editTextAltura);
        campoPeso = findViewById(R.id.editTextPeso);

        // Variaveis para recuperar (Get) e converter em (String):
        String altura = campoAltura.getText().toString();
        String peso = campoPeso.getText().toString();

        //Converter os dados para Numerico:
        Double numAltura = Double.parseDouble(altura);
        Double numPeso = Double.parseDouble(peso);
        Double numIMC = numPeso / (numAltura * numAltura);

        // Converter o resultado numImc -> String imc
        //String imc = String.value0f(numImc)
        DecimalFormat df = new DecimalFormat("##.##");
        String imc = df.format(numIMC);


    }


}